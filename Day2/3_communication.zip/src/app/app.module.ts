import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { NgModule, APP_BOOTSTRAP_LISTENER, ComponentRef } from '@angular/core';
import { RootComponent } from './root/root.component';
import { ListComponent } from './list/list.component';
import { CounterComponent } from './counter/counter.component';

@NgModule({
  declarations: [RootComponent, ListComponent, CounterComponent],
  imports: [BrowserModule, FormsModule],
  providers: [{
    provide: APP_BOOTSTRAP_LISTENER, multi: true, useFactory: () => {
      return (component: ComponentRef<any>) => {
        console.log(component);
      }
    }
  }],
  bootstrap: [RootComponent]
})
export class AppModule { }
