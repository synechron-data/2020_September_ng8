import { Component, ViewChild, ViewChildren, QueryList } from '@angular/core';
import { CounterComponent } from '../counter/counter.component';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html'
})
export class RootComponent {
  // @ViewChild("c1", { static: true })
  // counter1: CounterComponent;

  // @ViewChild("c2", { static: true })
  // counter2: CounterComponent;

  @ViewChildren(CounterComponent)
  counters: QueryList<CounterComponent>;

  pList: Array<string>;
  message: string;

  constructor() {
    this.pList = ["Manish", "Abhijeet", "Abhishek", "Ramakant", "Subodh"];
    this.message = "";
  }

  p2_reset(counter: CounterComponent) {
    counter.reset();
  }

  p3_reset() {
    // this.counter1.reset();
    // this.counter2.reset();

    for (const counter of this.counters.toArray()) {
      // counter.interval = 10;  
      counter.reset();
    }
  }

  updateMessage(flag: boolean) {
    if (flag)
      this.message = "Max Click Reached, please reset to continue...";
    else
      this.message = "";
  }
}
