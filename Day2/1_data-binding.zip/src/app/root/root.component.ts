import { Component, ChangeDetectionStrategy, AfterViewInit, NgZone } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html'
})
export class RootComponent implements AfterViewInit {
  message: string;
  flag: boolean;
  imageSource: any;
  h: number;
  w: number;

  constructor(private ngZone: NgZone) {
    this.message = "Hello World!"
    this.flag = false;
    this.imageSource = require('../../assets/image1.jpg');
    this.h = 200;
    this.w = 200;
  }

  ngAfterViewInit(): void {
    // document.getElementById("btnJS").addEventListener("click", () => {
    //   this.message = new Date().toTimeString();
    //   console.log(this.message);
    // });

    this.ngZone.runOutsideAngular(() => {
      document.getElementById("btnJS").addEventListener("click", () => {
        this.message = new Date().toTimeString();
        console.log(this.message);
      });
    })
  }

  doChange() {
    this.message = new Date().toTimeString();
  }

  doUpdate(city: string) {
    this.message = "You are from: " + city;
  }
}
