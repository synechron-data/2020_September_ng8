import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'validation-form',
  templateUrl: './validation-form.component.html',
  styles: []
})
export class ValidationFormComponent implements OnInit {
  regForm: FormGroup;

  constructor(private frmBuilder: FormBuilder) { }

  get frm() { return this.regForm.controls; }
  get address() { return (<FormGroup>this.regForm.controls.address).controls; }

  ngOnInit() {
    this.regForm = this.frmBuilder.group({
      firstname: ["", Validators.required],
      lastname: ["", Validators.compose([
        Validators.required,
        Validators.minLength(2),
        Validators.maxLength(6)
      ])],
      address: this.frmBuilder.group({
        city: ["", Validators.required],
        zip: [0, Validators.required]
      })
    });
  }

  logForm() {
    if (this.regForm.valid) {
      // Code to send data to API
      console.log(this.regForm.value);
    } else {
      this.regForm.markAllAsTouched();
      console.error("Invalid Form Data...");
    }
  }
}
