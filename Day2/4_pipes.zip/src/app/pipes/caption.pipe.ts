import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'caption'
})
export class CaptionPipe implements PipeTransform {
  transform(value: boolean, ...args: any[]): any {
    if (value)
      return "Show Short Date";
    else
      return "Show Full Date";
  }
}
