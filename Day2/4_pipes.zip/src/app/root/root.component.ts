import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html'
})
export class RootComponent {
  pList: Array<string>;
  name: string;
  today: Date;
  flag: boolean;

  constructor() {
    this.pList = ["Manish", "Abhijeet", "Kedar", "Avinash", "Mohit", "Ashish", "Ankur", "Kumud"];
    this.name = "manish sharma";
    this.today = new Date();
    this.flag = true;
  }

  get format() { return this.flag && 'fullDate' || 'shortDate' }

  updateFlag() {
    this.flag = !this.flag;
  }
}
