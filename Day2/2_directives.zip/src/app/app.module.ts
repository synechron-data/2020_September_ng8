import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { NgModule, APP_BOOTSTRAP_LISTENER, ComponentRef } from '@angular/core';
import { RootComponent } from './root/root.component';
import { AssignTwoComponent } from './assign-two/assign-two.component';
import { ListComponent } from './list/list.component';
import { HighlightDirective } from './directives/highlight.directive';
import { ChangeContentDirective } from './directives/change-content.directive';

@NgModule({
  declarations: [RootComponent, AssignTwoComponent, ListComponent, HighlightDirective, ChangeContentDirective],
  imports: [BrowserModule, FormsModule],
  providers: [{
    provide: APP_BOOTSTRAP_LISTENER, multi: true, useFactory: () => {
      return (component: ComponentRef<any>) => {
        console.log(component);
      }
    }
  }],
  bootstrap: [RootComponent]
})
export class AppModule { }
