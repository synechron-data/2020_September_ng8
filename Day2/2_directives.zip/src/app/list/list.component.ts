import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styles: []
})
export class ListComponent implements OnInit {
  personList: Array<string>;
  selected: string;

  constructor() { }

  ngOnInit() {
    this.personList = ["Manish", "Abhijeet", "Abhishek", "Ramakant", "Subodh"];
  }

  select(name: string, event: Event) {
    this.selected = name;
    event.preventDefault();
  }
}
