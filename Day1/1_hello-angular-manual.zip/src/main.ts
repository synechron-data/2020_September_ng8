import '../public/favicon.ico';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from './app/app.module';
import { platformBrowser } from '@angular/platform-browser';

platformBrowserDynamic().bootstrapModule(AppModule);

// platformBrowser().bootstrapModuleFactory(AppModuleFactory);