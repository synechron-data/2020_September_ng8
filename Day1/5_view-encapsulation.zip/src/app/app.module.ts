import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_BOOTSTRAP_LISTENER, ComponentRef } from '@angular/core';
import { CompOneComponent } from './comp-one/comp-one.component';
import { CompTwoComponent } from './comp-two/comp-two.component';
import { RootComponent } from './root/root.component';

@NgModule({
  declarations: [CompOneComponent, CompTwoComponent, RootComponent],
  imports: [BrowserModule],
  providers: [{
    provide: APP_BOOTSTRAP_LISTENER, multi: true, useFactory: () => {
      return (component: ComponentRef<any>) => {
        console.log(component);
      }
    }
  }],
  bootstrap: [RootComponent]
})
export class AppModule { }
