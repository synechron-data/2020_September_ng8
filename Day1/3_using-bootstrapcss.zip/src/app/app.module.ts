// import { BrowserModule } from '@angular/platform-browser';
// import { NgModule, APP_BOOTSTRAP_LISTENER, ComponentRef } from '@angular/core';
// import { HelloComponent } from './hello/hello.component';
// import { CompOneComponent } from './comp-one/comp-one.component';
// import { CompTwoComponent } from './comp-two/comp-two.component';

// @NgModule({
//   declarations: [HelloComponent, CompOneComponent, CompTwoComponent],
//   imports: [BrowserModule],
//   providers: [{
//     provide: APP_BOOTSTRAP_LISTENER, multi: true, useFactory: () => {
//       return (component: ComponentRef<any>) => {
//         console.log(component);
//       }
//     }
//   }],
//   bootstrap: [CompOneComponent, CompTwoComponent]
// })
// export class AppModule { }


import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_BOOTSTRAP_LISTENER, ComponentRef } from '@angular/core';
import { HelloComponent } from './hello/hello.component';
import { CompOneComponent } from './comp-one/comp-one.component';
import { CompTwoComponent } from './comp-two/comp-two.component';
import { RootComponent } from './root/root.component';

@NgModule({
  declarations: [HelloComponent, CompOneComponent, CompTwoComponent, RootComponent],
  imports: [BrowserModule],
  providers: [{
    provide: APP_BOOTSTRAP_LISTENER, multi: true, useFactory: () => {
      return (component: ComponentRef<any>) => {
        console.log(component);
      }
    }
  }],
  bootstrap: [RootComponent]
})
export class AppModule { }
