import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp-two',
  template: `
    <h1 class="text-success">Hello from Component Two - Module Two!</h1>
    <app-s-com></app-s-com>
  `,
  styles: []
})
export class CompTwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
