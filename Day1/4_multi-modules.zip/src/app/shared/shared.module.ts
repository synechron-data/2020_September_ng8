import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SComComponent } from './s-com/s-com.component';

@NgModule({
  declarations: [SComComponent],
  exports: [SComComponent]
})
export class SharedModule { }
