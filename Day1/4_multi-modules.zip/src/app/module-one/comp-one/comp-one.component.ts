import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp-one',
  template: `
    <h1 class="text-info">Hello from Component One - Module One!</h1>
    <app-s-com></app-s-com>
  `,
  styles: []
})
export class CompOneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
