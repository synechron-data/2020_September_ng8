import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CompOneComponent } from './comp-one/comp-one.component';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  imports: [SharedModule],
  declarations: [CompOneComponent],
  exports: [CompOneComponent]
})
export class ModuleOneModule { }
