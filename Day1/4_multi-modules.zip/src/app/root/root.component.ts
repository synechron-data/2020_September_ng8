import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <div class="container">
        <app-comp-one></app-comp-one>
        <app-comp-two></app-comp-two>
    </div>
  `,
  styles: []
})
export class RootComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
