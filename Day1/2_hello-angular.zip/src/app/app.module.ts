import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HelloComponent } from './hello/hello.component';
import { CompOneComponent } from './comp-one/comp-one.component';
import { CompTwoComponent } from './comp-two/comp-two.component';

@NgModule({
  declarations: [HelloComponent, CompOneComponent, CompTwoComponent],
  imports: [BrowserModule],
  providers: [],
  bootstrap: []
})
export class AppModule { }
