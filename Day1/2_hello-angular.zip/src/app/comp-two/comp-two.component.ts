import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comp-two',
  template: `
    <p>
      comp-two works!
    </p>
  `,
  styles: []
})
export class CompTwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
