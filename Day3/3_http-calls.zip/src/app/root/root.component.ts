import { Component, OnDestroy, OnInit } from '@angular/core';
import { Post } from '../models/post.model';
import { Subscription } from 'rxjs';
import { PostService } from '../services/post.service';

@Component({
  selector: 'app-root',
  templateUrl: './root.component.html',
  providers: [PostService]
})
export class RootComponent implements OnInit, OnDestroy {
  message: string;
  posts: Array<Post>;
  get_Sub: Subscription;
  post_Sub: Subscription;
  del_Sub: Subscription;

  newPost: Post = {
    userId: 1,
    id: 0,
    title: "Test",
    body: "Test"
  };

  constructor(private _pService: PostService) {
    this.message = "Loading Data, please wait...";
  }

  deletePost(id: number, event: Event) {
    event.preventDefault();
    console.log("Id to delete: ", id);
    this.del_Sub = this._pService.deletePost(id).subscribe(() => {
      this.posts = [...this.posts.filter(p => p.id !== id)];
      this.message = "Record Deleted...";
      setTimeout(() => {
        this.message = "";
      }, 2000);
    }, (err: string) => {
      this.message = err;
    });
    // Code to send id to service delete method
  }

  insertPost() {
    this.post_Sub = this._pService.addPost(this.newPost).subscribe(resData => {
      this.posts.unshift(resData);
      this.message = "";
    }, (err: string) => {
      this.message = err;
    });
  }

  ngOnInit(): void {
    this.get_Sub = this._pService.getPosts().subscribe(resData => {
      this.posts = resData;
      this.message = "";
    }, (err: string) => {
      this.message = err;
    });
  }

  ngOnDestroy(): void {
    this.get_Sub.unsubscribe();
    this.post_Sub.unsubscribe();
  }
}

// -------------------------------------------------------------------------------------------
// import { HttpErrorResponse } from '@angular/common/http'
// import { Post } from '../models/post.model';
// import { Subscription } from 'rxjs';
// import { PostService } from '../services/post.service';

// @Component({
//   selector: 'app-root',
//   templateUrl: './root.component.html',
//   providers: [PostService]
// })
// export class RootComponent implements OnInit, OnDestroy {
//   message: string;
//   posts: Array<Post>;
//   get_Sub: Subscription;

//   constructor(private _pService: PostService) {
//     this.message = "Loading Data, please wait...";
//   }

//   ngOnInit(): void {
//     this.get_Sub = this._pService.getPosts().subscribe(resData => {
//       this.posts = resData;
//       this.message = "";
//     }, (err: HttpErrorResponse) => {
//       this.message = err.message;
//     });
//   }

//   ngOnDestroy(): void {
//     this.get_Sub.unsubscribe();
//   }
// }

// --------------------------------------------------------------------------------------------
// import { Component, OnDestroy, OnInit } from '@angular/core';
// import { HttpClient, HttpErrorResponse } from '@angular/common/http'
// import { Post } from '../models/post.model';
// import { Subscription } from 'rxjs';

// @Component({
//   selector: 'app-root',
//   templateUrl: './root.component.html'
// })
// export class RootComponent implements OnInit, OnDestroy {
//   url: string;
//   message: string;
//   posts: Array<Post>;
//   get_Sub: Subscription;

//   constructor(private httpClient: HttpClient) {
//     this.url = "https://jsonplaceholder.typicode.com/posts";
//     this.message = "Loading Data, please wait...";
//   }

//   ngOnInit(): void {
//     this.get_Sub = this.httpClient.get<Array<Post>>(this.url).subscribe(resData => {
//       this.posts = resData;
//       this.message = "";
//     }, (err: HttpErrorResponse) => {
//       this.message = err.message;
//     });
//   }

//   ngOnDestroy(): void {
//     this.get_Sub.unsubscribe();
//   }
// }
