import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule, APP_BOOTSTRAP_LISTENER, ComponentRef } from '@angular/core';
import { RootComponent } from './root/root.component';
import { HttpClientModule } from '@angular/common/http';
// import { PostService } from './services/post.service';

@NgModule({
  declarations: [RootComponent],
  imports: [BrowserModule, FormsModule, ReactiveFormsModule, HttpClientModule],
  providers: [
    // PostService,
    {
      provide: APP_BOOTSTRAP_LISTENER, multi: true, useFactory: () => {
        return (component: ComponentRef<any>) => {
          console.log(component);
        }
      }
    }
  ],
  bootstrap: [RootComponent]
})
export class AppModule { }
