import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'product-not-selected',
  template: `
    <div class="outerdiv">
      <div class="innerdiv">
          <h3 class="text-warning">Please select a product</h3>
      </div>
    </div>
  `,
  styles: []
})
export class ProductNotSelectedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
