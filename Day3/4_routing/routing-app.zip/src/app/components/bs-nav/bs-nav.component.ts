import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'bs-nav',
  templateUrl: './bs-nav.component.html',
  styleUrls: ['./bs-nav.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class BsNavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
