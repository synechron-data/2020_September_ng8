import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { RootComponent } from './components/root/root.component';
import { BsNavComponent } from './components/bs-nav/bs-nav.component';
import { HomeComponent } from './components/home/home.component';
import { AboutComponent } from './components/about/about.component';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { AuthorsModule } from './authors-module/authors-module.module';
import { ProductsComponent } from './components/products/products.component';
import { ProductNotSelectedComponent } from './components/product-not-selected/product-not-selected.component';
import { ProductDetailsComponent } from './components/product-details/product-details.component';
import { AdminComponent } from './components/admin/admin.component';
import { LoginComponent } from './components/login/login.component';
import { AuthGuardService } from './services/auth-guard.service';
import { AuthenticatorService } from './services/authenticator.service';
import { TokenInterceptorService } from './services/token-interceptor.service';

@NgModule({
  imports: [BrowserModule, ReactiveFormsModule, HttpClientModule, AppRoutingModule, AuthorsModule],
  declarations: [RootComponent, BsNavComponent, HomeComponent, AboutComponent, NotFoundComponent, ProductsComponent, ProductNotSelectedComponent, ProductDetailsComponent, AdminComponent, LoginComponent],
  providers: [
    AuthGuardService,
    AuthenticatorService,
    {
      provide: HTTP_INTERCEPTORS,
      multi: true,
      useClass: TokenInterceptorService
    }
  ],
  bootstrap: [RootComponent]
})
export class AppModule { }
